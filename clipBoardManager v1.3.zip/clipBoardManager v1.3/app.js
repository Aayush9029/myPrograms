let email;
let pass;

function login() {
  email = document.getElementById("email").value;
  pass = document.getElementById("password").value;
  console.log(email, pass);
  validateAccount(email, pass);
}

function signup() {
  email = document.getElementById("email").value;
  pass = document.getElementById("password").value;
  console.log(email, pass, "newuser");
}

function validateAccount(e, p) {
  if (e == "a@bc" && p == "123") {
    youIn();
    console.log("you're in ");
    // *executes a function that removes login and shows real clipboar manager*
  } else {
    console.log("tratior?");
    // see as a security level threat 1
    // threat ++
  }
}

function newUser(e, p) {
  // takes e and p and puts them in a firebase / json file so they can autheniticate later in other machines too
}

function youIn() {
  document.getElementById("holder").style.display = "none";
  document.getElementById("appHolder").style.display = "block";
}
